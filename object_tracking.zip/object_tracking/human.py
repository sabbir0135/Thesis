import cv2

# Load the Haar cascade file for human detection
cascade_path = cv2.data.haarcascades + 'haarcascade_fullbody.xml'
cascade = cv2.CascadeClassifier(cascade_path)

# Open the video file
video_path = 'v4.mp4'
cap = cv2.VideoCapture(video_path)

while cap.isOpened():
    # Read the current frame
    ret, frame = cap.read()

    if not ret:
        break

    # Convert the frame to grayscale for human detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Perform human detection
    humans = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    # Draw bounding boxes around detected humans
    for (x, y, w, h) in humans:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # Display the frame with detected humans
    cv2.imshow('Human Detection', frame)

    # Exit if the 'q' key is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture and close all windows
cap.release()
cv2.destroyAllWindows()
