import cv2
import time
import math

# Load the Haar cascade file for human detection
cascade_path = cv2.data.haarcascades + 'haarcascade_fullbody.xml'
cascade = cv2.CascadeClassifier(cascade_path)

# Open the video file
video_path = 'v3.mp4'
cap = cv2.VideoCapture(video_path)

# Initialize variables for motion detection
prev_frame = None
motion_threshold = 1000  # Adjust this threshold according to your needs

# Initialize variables for trajectory
trajectory_color = (255, 0, 0)  # Blue color for trajectory
trajectory_thickness = 2
prev_center = None

# Initialize variables for speed detection
fps = cap.get(cv2.CAP_PROP_FPS)  # Get frames per second
prev_time = time.time()
prev_speed = None

while cap.isOpened():
    # Read the current frame
    ret, frame = cap.read()

    if not ret:
        break

    # Convert the frame to grayscale for motion detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (21, 21), 0)

    # Perform motion detection
    if prev_frame is not None:
        frame_diff = cv2.absdiff(prev_frame, gray)
        _, thresh = cv2.threshold(frame_diff, motion_threshold, 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Iterate over contours and detect humans
        for contour in contours:
            if cv2.contourArea(contour) > motion_threshold:
                (x, y, w, h) = cv2.boundingRect(contour)
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

                # Calculate the center of the bounding box
                center = (x + w // 2, y + h // 2)

                # Draw a line from the previous center to the current center
                if prev_center is not None:
                    cv2.line(frame, prev_center, center, trajectory_color, trajectory_thickness)

                    # Calculate speed (pixels per second)
                    distance = math.sqrt((center[0] - prev_center[0]) ** 2 + (center[1] - prev_center[1]) ** 2)
                    speed = distance * fps

                    # Display speed on the frame
                    if prev_speed is not None:
                        cv2.putText(frame, f"Speed: {speed:.2f} pixels/s", (x, y - 10),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

                    prev_speed = speed

                # Update the previous center
                prev_center = center

    # Update the previous frame
    prev_frame = gray

    # Perform human detection
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    humans = cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    # Draw bounding boxes around detected humans
    for (x, y, w, h) in humans:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)

    # Display the frame with detected humans and motion
   
